# vessel-impact-detection
OpenCV project to detect the speed at which vessels collide with the pier. Also planned to calculate the mass of the vessel from the water level on the hull and get to the impact force
